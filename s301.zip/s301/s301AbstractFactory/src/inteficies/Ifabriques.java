package inteficies;

/**
 * Intef�cie amb els possibles m�todes dels objectes creats per FabricaAdr i
 * FabricaNum
 * 
 * @author jsedo
 *
 */
public interface Ifabriques {
	Inum getNum(String pa�s);

	Iadr getAdr(String pa�s);
}
