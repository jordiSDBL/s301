package inteficies;

/**
 * Intef�cie amb el m�tode com� a tot objecte creat del paquet entrades.numeros
 * 
 * @author jsedo
 *
 */
public interface Inum {
	void afegirNum();
}
