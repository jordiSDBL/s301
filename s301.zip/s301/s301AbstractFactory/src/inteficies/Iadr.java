package inteficies;

/**
 * Intef�cie amb el m�tode com� a tot objecte creat del paquet entrades.adreces
 * 
 * @author jsedo
 *
 */
public interface Iadr {
	void afegirAdreca();
}
