package app;

import fabriques.FabricaProductora;
import inteficies.*;

public class App {

	public static void main(String[] args) {
		/**
		 * Amb el m�tode de la f�brica de f�briques creem la f�brica que passem per
		 * par�metre
		 */
		Ifabriques f1 = FabricaProductora.getFactory("Numero");
		/**
		 * Amb el m�tode d'aquesta f�brica, creem un objecte de NumBR.
		 */
		Inum num1 = f1.getNum("Brasil");
		/**
		 * Amb aquest objecte creat, podem invocar el m�tode sobreescrit
		 */
		num1.afegirNum();

		Ifabriques f2 = FabricaProductora.getFactory("Adre�a");
		Iadr adr1 = f2.getAdr("Espanya");

		adr1.afegirAdreca();
	}

}
