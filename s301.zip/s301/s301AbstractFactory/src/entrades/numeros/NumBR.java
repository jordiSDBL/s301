package entrades.numeros;

import inteficies.Inum;

/**
 * Classe d'aquest tipus de n�mero. Al constructor s'inicialitzen els valors
 * codi de pa�s i pa�s. Per practicitat no es demanen m�s dades per crear
 * l'objecte al principi.
 * 
 * @author jsedo
 *
 */
public class NumBR implements Inum {

	private String codiInternacional;
	private String numeroLocal;
	private String numeroInternacional;
	private String pais;

	public NumBR() {
		this.codiInternacional = "+55 ";
		this.numeroInternacional = this.codiInternacional + this.numeroLocal;
		this.pais = "Brasil";
	}

	/**
	 * M�tode sobreescrit de la interf�cie Inum
	 */
	@Override
	public void afegirNum() {
		System.out.println(
				"S'ha afegir al directori el seg�ent n�mero internacional:\n" + this.numeroInternacional + ".");
	}

	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("NumBR [codiInternacional=");
		builder.append(codiInternacional);
		builder.append(", numeroLocal=");
		builder.append(numeroLocal);
		builder.append(", numeroInternacional=");
		builder.append(numeroInternacional);
		builder.append(", pais=");
		builder.append(pais);
		builder.append("]");
		return builder.toString();
	}

}
