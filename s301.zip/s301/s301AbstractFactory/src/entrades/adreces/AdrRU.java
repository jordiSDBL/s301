package entrades.adreces;

import inteficies.Iadr;

/**
 * Classe d'aquest tipus d'adre�a. Al constructor s'inicialitzen els valors
 * pa�s. Per practicitat no es demanen m�s dades per crear l'objecte al
 * principi.
 * 
 * @author jsedo
 *
 */
public class AdrRU implements Iadr {

	private String carrer;
	private int num;
	private int pis;
	private String porta;
	private int cp;
	private String municipi;
	private String pais;

	public AdrRU() {
		this.pais = "R�ssia";
	}

	/**
	 * M�tode sobreescrit de la interf�cie Iadr
	 */
	@Override
	public void afegirAdreca() {
		System.out.println("S'ha afegit la seg�ent adre�a al directori.");
		System.out.println(toString());
	}

	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("C/ ");
		builder.append(carrer);
		builder.append(", num. ");
		builder.append(num);
		builder.append(", ");
		builder.append(pis);
		builder.append(", ");
		builder.append(porta);
		builder.append(", cp: ");
		builder.append(cp);
		builder.append(", ");
		builder.append(municipi);
		builder.append(", ");
		builder.append(pais);
		builder.append(".");
		return builder.toString();
	}
}
