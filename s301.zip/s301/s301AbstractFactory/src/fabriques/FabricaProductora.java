package fabriques;

import inteficies.Ifabriques;

/**
 * F�brica de f�briques. Pel seu m�tode s'hi passa per par�metre un string de la
 * f�brica que es vol crear i en crida el constructor.
 * 
 * @author jsedo
 *
 */
public class FabricaProductora {

	public static Ifabriques getFactory(String tipusFabrica) {

		if (tipusFabrica.equalsIgnoreCase("Numero")) {
			return new FabricaNum();

		} else if (tipusFabrica.equalsIgnoreCase("Adre�a")) {
			return new FabricaAdr();
		}

		return null;
	}

}