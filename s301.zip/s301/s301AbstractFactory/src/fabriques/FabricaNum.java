package fabriques;

import entrades.numeros.*;
import inteficies.*;

/**
 * F�brica de n�meros. Al seu m�tode s'hi passa per par�metre un string amb el
 * tipus de numero a crear i en crida el constructor.
 * 
 * @author jsedo
 *
 */
public class FabricaNum implements Ifabriques {

	@Override
	public Inum getNum(String pais) {
		if (pais.equalsIgnoreCase("Brasil")) {
			return new NumBR();
		} else if (pais.equalsIgnoreCase("Espanya")) {
			return new NumES();
		} else if (pais.equalsIgnoreCase("Fran�a")) {
			return new NumFR();
		} else if (pais.equalsIgnoreCase("R�ssia")) {
			return new NumRU();
		}
		return null;
	}

	@Override
	public Iadr getAdr(String pais) {
		return null;
	}
}