package fabriques;

import entrades.adreces.*;
import inteficies.*;

/**
 * F�brica d'adreces. Al seu m�tode s'hi passa per par�metre un string amb el
 * tipus de numero a crear i en crida el constructor.
 * 
 * @author jsedo
 *
 */
public class FabricaAdr implements Ifabriques {

	@Override
	public Iadr getAdr(String pais) {
		if (pais.equalsIgnoreCase("Brasil")) {
			return new AdrBR();
		} else if (pais.equalsIgnoreCase("Espanya")) {
			return new AdrES();
		} else if (pais.equalsIgnoreCase("Fran�a")) {
			return new AdrFR();
		} else if (pais.equalsIgnoreCase("R�ssia")) {
			return new AdrRU();
		}
		return null;
	}

	@Override
	public Inum getNum(String pais) {
		return null;
	}
}
