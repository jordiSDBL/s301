package app;

import gestioComandos.Undo;
import utilities.Menu;

public class App {

	public static void main(String[] args) {
		/**
		 * Si no existeix, creem una inst�ncia d'Undo, si ja s'havia instanciat abans,
		 * la recuperem.
		 */
		Undo u = Undo.getInstancia();

		/**
		 * Pregutem qu� vol fer a l'usuari, se li desplega el men� d'opcions.
		 */
		int seguir;
		do {
			seguir = Menu.opcions(u);
		} while (seguir != 0);
	}
}
