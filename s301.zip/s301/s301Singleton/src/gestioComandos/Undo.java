package gestioComandos;

import java.util.*;

import utilities.Teclado;

public class Undo {

	// Atributs
	private static Undo instancia;
	public Set<String> comandos = new HashSet<String>();
	public List<String> historic = new ArrayList<String>();

	/**
	 * constructor privat perqu� per patr� de disseny nom�s voldrem que s'instancii una
	 * vegada, aix� que ho farem a trav�s del m�tode getInstancia()
	 */
	private Undo() {

	}

	/**
	 * M�tode per crear la inst�ncia amb qu� es treballar�. En cas que encara no
	 * s'hagi instanciat Undo, llavors far� crida al m�tode privat de la classe.
	 * Retorna una instancia de classe.
	 * 
	 * @return instancia
	 */
	public static Undo getInstancia() {
		if (instancia == null) {
			instancia = new Undo();
		}
		return instancia;
	}

	/**
	 * Afegim comandos, els emmagatzemem dins un Set.
	 * Tamb� l'afegim a la List que anir� recollint tots els comandos que s'executin.
	 */
	public void afegirComandos() {
		String comando = Teclado.leerString("Introdueix el comando a afegir:\n");
		comandos.add(comando);
		System.out.println();
		historic.add(comando);
	}

	/**
	 * Eliminem comandos, els treiem del HashSet per nom.
	 * Tamb� afegim el comando a la List que anir� recollint tots els comandos que s'executin.
	 */
	public void eliminarComandos() {
		String comando = Teclado.leerString("Introdueix el comando a esborrar:\n");
		comandos.remove(comando);
		System.out.println();
		historic.add(comando);
	}

	/**
	 * Imprimeix en ordre invers els comandos executats.
	 * Es podria afegir un topall tamb�, perqu� fos nom�s els X �ltims.
	 */
	public void llistar�ltimsComandos() {
		System.out.println("�ltims comandos introdu�ts:");
		for (int i = 0; i < historic.size(); i++) {
			System.out.println(historic.get(historic.size() - 1 - i));
		}
		System.out.println();
	}

}
