package utilities;

import gestioComandos.Undo;

public class Menu {
	/**
	 * Amb aquest m�tode l'usuari podr� interactuar amb les opcions que t�
	 * l'aplicaci�.
	 * 
	 * @param c
	 * @return
	 */
	public static int opcions(Undo c) {
		int selec;

		selec = Teclado.leerInt("--------------------\n"
				+ "Introdueix opci�:\n"
				+ "1- Afegeix comando\n"
				+ "2- Elimina comando\n"
				+ "3- Llista comandos\n"
				+ "0- Surt\n"
				+ "--------------------\n");
		
		switch (selec) {
			case 1:
				c.afegirComandos();
				break;
			case 2:
				c.eliminarComandos();
				break;
			case 3:
				c.llistar�ltimsComandos();
				break;
			case 0:
				System.out.println("S'ha tancat l'aplicaci�.");
				break;
		}

		return selec;
	}
}
