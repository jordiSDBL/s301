package comandos;

import interficies.*;

/**
 * Per crear un comando per accelerar(). Aquest m�tode es troba encapsulat en la
 * sobreescriptura de execute() de la interf�cie IOperacio de la que implementen
 * tots els tipus de comandos.
 * 
 * @author jsedo
 *
 */
public class AccelerarImpl implements IOperacio {
	private IVehicles vehicle;

	public AccelerarImpl(IVehicles vehicle) {
		this.vehicle = vehicle;
	}

	@Override
	public void execute() {
		this.vehicle.accelerar();
	}

}
