package comandos;

import interficies.*;

/**
 * Per crear un comando per frenar(). Aquest m�tode es troba encapsulat en la
 * sobreescriptura de execute() de la interf�cie IOperacio de la que implementen
 * tots els tipus de comandos.
 * 
 * @author jsedo
 *
 */
public class FrenarImpl implements IOperacio {
	private IVehicles vehicle;

	public FrenarImpl(IVehicles vehicle) {
		this.vehicle = vehicle;
	}

	@Override
	public void execute() {
		this.vehicle.frenar();
	}

}