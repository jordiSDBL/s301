package comandos;

import java.util.*;
import interficies.IOperacio;

/**
 * Es caracteritza per tenir un m�tode que rebr� comandos i els anir� acumulant
 * al seu atribut llista del tipus interf�cie de comandos.
 * Tamb� cont� un m�tode per executar tots els comandos emmagatzemats a la llista.
 * 
 * @author jsedo
 *
 */
public class Invocador {

	private List<IOperacio> accions = new ArrayList<>();

	public void rebreAccio(IOperacio accio) {
		this.accions.add(accio);
	}

	public void realitzarAccions() {
		this.accions.forEach(x -> x.execute());
		this.accions.clear(); // deixa la llista neta per futurs usus.
	}

}