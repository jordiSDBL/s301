package fabrica;

import interficies.IVehicles;
import vehicles.*;

/**
 * Triem el patr� Factory per crear els diferents tipus de vehicles que pot
 * tenir el parking
 * 
 * @author jsedo
 *
 */
public class Parking {

	public IVehicles getVehicle(String tipus) {

		if (tipus.equalsIgnoreCase("Avi�")) {
			return new Avio();
		} else if (tipus.equalsIgnoreCase("Bicicleta")) {
			return new Bicicleta();
		} else if (tipus.equalsIgnoreCase("Cotxe")) {
			return new Cotxe();
		} else if (tipus.equalsIgnoreCase("Vaixell")) {
			return new Vaixell();
		}
		return null;
	}
}
