package vehicles;

import interficies.IVehicles;

/**
 * Classe en qu� se sobreescriuen i concreta el funcionament del m�todes de
 * IVehicles per a aquesta classe en concret.
 * 
 * @author jsedo
 *
 */
public class Cotxe implements IVehicles{
	public static int id = 1;
	private int idCotxe;
	private String model;
	private String propietari;
	
	public Cotxe() {
		this.idCotxe = Cotxe.id++;
	}
	@Override
	public void arrencar() {
		System.out.println("El cotxe amb id " + this.idCotxe + " ha arrencat.");
	}
	@Override
	public void accelerar() {
		System.out.println("El cotxe amb id " + this.idCotxe + " ha accelerat.");
	}
	@Override
	public void frenar() {
		System.out.println("El cotxe amb id " + this.idCotxe + " ha frenat.");
	}

	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("Cotxe [idCotxe=");
		builder.append(idCotxe);
		builder.append(", model=");
		builder.append(model);
		builder.append(", propietari=");
		builder.append(propietari);
		builder.append("]");
		return builder.toString();
	}
	
	
}
