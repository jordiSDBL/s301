package vehicles;

import interficies.IVehicles;

/**
 * Classe en qu� se sobreescriuen i concreta el funcionament del m�todes de
 * IVehicles per a aquesta classe en concret.
 * 
 * @author jsedo
 *
 */
public class Avio implements IVehicles {
	public static int id = 1;
	private int idAvio;
	private String model;
	private String propietari;

	public Avio() {
		this.idAvio = Avio.id++;
	}

	@Override
	public void arrencar() {
		System.out.println("L'avi� amb id " + this.idAvio + " ha arrencat.");
	}

	@Override
	public void accelerar() {
		System.out.println("L'avi� amb id " + this.idAvio + " ha accelerat.");
	}

	@Override
	public void frenar() {
		System.out.println("L'avi� amb id " + this.idAvio + " ha frenat.");
	}

	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("Avio [id=");
		builder.append(id);
		builder.append(", model=");
		builder.append(model);
		builder.append(", propietari=");
		builder.append(propietari);
		builder.append("]");
		return builder.toString();
	}

}
