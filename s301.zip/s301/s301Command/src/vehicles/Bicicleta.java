package vehicles;

import interficies.IVehicles;

/**
 * Classe en qu� se sobreescriuen i concreta el funcionament del m�todes de
 * IVehicles per a aquesta classe en concret.
 * 
 * @author jsedo
 *
 */
public class Bicicleta implements IVehicles{
	public static int id = 1;
	private int idBici;
	private String model;
	private String propietari;
	
	public Bicicleta() {
		this.idBici = Bicicleta.id++;
	}
	@Override
	public void arrencar() {
		System.out.println("La bicicleta amb id " + this.idBici + " ha arrencat.");
	}
	@Override
	public void accelerar() {
		System.out.println("La bicicleta amb id " + this.idBici + " ha accelerat.");
	}
	@Override
	public void frenar() {
		System.out.println("La bicicleta amb id " + this.idBici + " ha frenat.");
	}

	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("Bicicleta [idBici=");
		builder.append(idBici);
		builder.append(", model=");
		builder.append(model);
		builder.append(", propietari=");
		builder.append(propietari);
		builder.append("]");
		return builder.toString();
	}
	
	
}
