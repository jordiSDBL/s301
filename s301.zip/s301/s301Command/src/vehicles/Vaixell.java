package vehicles;

import interficies.IVehicles;

/**
 * Classe en qu� se sobreescriuen i concreta el funcionament del m�todes de
 * IVehicles per a aquesta classe en concret.
 * 
 * @author jsedo
 *
 */
public class Vaixell implements IVehicles{
	public static int id = 1;
	private int idVaixell;
	private String model;
	private String propietari;
	
	public Vaixell() {
		this.idVaixell = Vaixell.id++;
	}
	@Override
	public void arrencar() {
		System.out.println("El vaixell amb id " + this.idVaixell + " ha arrencat.");
	}
	@Override
	public void accelerar() {
		System.out.println("El vaixell amb id " + this.idVaixell + " ha accelerat.");
	}
	@Override
	public void frenar() {
		System.out.println("El vaixell amb id " + this.idVaixell + " ha frenat.");
	}

	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("Vaixell [idVaixell=");
		builder.append(idVaixell);
		builder.append(", model=");
		builder.append(model);
		builder.append(", propietari=");
		builder.append(propietari);
		builder.append("]");
		return builder.toString();
	}
	
	
}
