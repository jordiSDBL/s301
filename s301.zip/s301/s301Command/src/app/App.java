package app;

import comandos.*;
import fabrica.Parking;
import interficies.IVehicles;

public class App {
	public static void main(String[] args) {
		/**
		 * Creem una "f�brica de vehicles" classe Parking.
		 */
		Parking park1 = new Parking();
		/**
		 * Gr�cies al m�tode getVehicle() de Parking podem passar per par�metre quin
		 * tipus de vehicle volem crear i els anem desant en variables del tipus
		 * IVehicles, ja que totes les classes diferents de vehicles implementen
		 * d'aquesta.
		 */
		IVehicles vh1 = park1.getVehicle("Avi�");
		IVehicles vh2 = park1.getVehicle("Bicicleta");
		IVehicles vh3 = park1.getVehicle("Cotxe");
		IVehicles vh4 = park1.getVehicle("Cotxe");
		IVehicles vh5 = park1.getVehicle("Vaixell");

		/**
		 * Creem un invocador i hi passem les accions que vulguem per par�metre del seu
		 * m�tode rebreAccio(). Aquestes accions les passem amb el contructor de cada
		 * implementaci� de comando sobre el vehicle que li indiquem per par�metre.
		 */
		Invocador ivc = new Invocador();
		ivc.rebreAccio(new ArrencarImpl(vh1));
		ivc.rebreAccio(new ArrencarImpl(vh2));
		ivc.rebreAccio(new ArrencarImpl(vh3));
		ivc.rebreAccio(new ArrencarImpl(vh4));
		ivc.rebreAccio(new AccelerarImpl(vh4));
		ivc.rebreAccio(new FrenarImpl(vh4));
		ivc.rebreAccio(new ArrencarImpl(vh5));
		/**
		 * Per �ltim, invoquem el m�tode que fa execute() a tots el comandos
		 * emmagatzemats a la llista de l'invocar que acabavem d'afegir.
		 */
		ivc.realitzarAccions();
	}
}
