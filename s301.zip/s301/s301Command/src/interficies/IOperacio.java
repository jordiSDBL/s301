package interficies;

/**
 * Els comandos sobrrescriuran aquest m�tode que encapsula el m�tode concret
 * dels vehicles que vulgui cridar.
 * 
 * @author jsedo
 *
 */
@FunctionalInterface
public interface IOperacio {

	void execute();
}
