package interficies;

/**
 * Els m�todes comuns dels vehicles, que aquests sobreescriuran.
 * 
 * @author jsedo
 *
 */
public interface IVehicles {
	void arrencar();

	void accelerar();

	void frenar();
}
